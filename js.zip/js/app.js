var app = angular.module('StockMapNewsApp', ['leaflet-directive', 'ngRoute']);
app.config(function ($routeProvider) {
  $routeProvider
  .when('/map', {
    controller: 'MapController',
    templateUrl: 'views/map.html'
  })
  .when('/news', {
    controller: 'NewsController',
    templateUrl: 'views/news.html'
  })
  .otherwise({
    redirectTo: '/map'
  });
});
