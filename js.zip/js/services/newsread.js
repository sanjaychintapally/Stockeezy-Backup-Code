app.factory('places', ['$http', ($http) => {
  return $http.jsonp('https://news.api/v4/economictimes')
    .success(data => data)
    .error(err => err)	
}]);
